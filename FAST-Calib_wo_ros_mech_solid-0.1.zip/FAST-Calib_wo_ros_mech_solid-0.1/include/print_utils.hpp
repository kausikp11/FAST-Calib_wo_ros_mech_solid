#pragma once
#include <iostream>
#include <string>
#include "struct.hpp"

void printCameraIntrinsics(const CameraIntrinsics& params);